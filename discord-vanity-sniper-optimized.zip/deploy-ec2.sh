#!/usr/bin/env bash
# ============================================================
#  Deploy AeroX Vanity Sniper to AWS EC2 (Amazon Linux 2023)
#
#  Run this ON YOUR OWN MACHINE (needs AWS CLI + credentials).
#    aws configure          # once
#    ./deploy-ec2.sh
#
#  Override any default with env vars, e.g.:
#    AWS_REGION=ap-south-1 INSTANCE_TYPE=t3.small ./deploy-ec2.sh
# ============================================================
set -euo pipefail

# ---------------- CONFIG (override via env) ----------------
REPO_URL="${REPO_URL:-https://github.com/dduhan9050-ai/vanity.git}"
BRANCH="${BRANCH:-main}"
INSTANCE_TYPE="${INSTANCE_TYPE:-t3.micro}"
KEY_NAME="${KEY_NAME:-vanity-sniper-key}"
SG_NAME="${SG_NAME:-vanity-sniper-sg}"
REGION="${AWS_REGION:-us-east-1}"
SSH_CIDR="${SSH_CIDR:-0.0.0.0/0}"   # tighten to your IP/32 for safety
# -----------------------------------------------------------

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m[ERROR] %s\033[0m\n' "$*" >&2; exit 1; }

command -v aws >/dev/null || die "AWS CLI not installed. Install it: https://docs.aws.amazon.com/cli/"
aws sts get-caller-identity >/dev/null 2>&1 || die "No AWS credentials. Run 'aws configure' first."

say "Region: $REGION | Type: $INSTANCE_TYPE | Repo: $REPO_URL"

# ---------- 1. Key pair ----------
if aws ec2 describe-key-pairs --key-names "$KEY_NAME" --region "$REGION" >/dev/null 2>&1; then
  say "Key pair '$KEY_NAME' already exists — reusing."
  [ -f "$KEY_NAME.pem" ] || echo "  NOTE: you don't have $KEY_NAME.pem locally; use an existing key to SSH."
else
  say "Creating key pair '$KEY_NAME'..."
  aws ec2 create-key-pair --key-name "$KEY_NAME" --region "$REGION" \
    --query 'KeyMaterial' --output text > "$KEY_NAME.pem"
  chmod 400 "$KEY_NAME.pem"
  echo "  Saved private key -> $KEY_NAME.pem (keep it safe!)"
fi

# ---------- 2. Latest Amazon Linux 2023 AMI (no hardcoded IDs) ----------
say "Resolving latest Amazon Linux 2023 AMI..."
AMI=$(aws ssm get-parameter --region "$REGION" \
  --name /aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64 \
  --query 'Parameter.Value' --output text)
[ -n "$AMI" ] || die "Could not resolve AMI for region $REGION"
echo "  AMI: $AMI"

# ---------- 3. Security group (SSH only, idempotent) ----------
SG_ID=$(aws ec2 describe-security-groups --region "$REGION" \
  --filters "Name=group-name,Values=$SG_NAME" \
  --query 'SecurityGroups[0].GroupId' --output text 2>/dev/null || true)

if [ -z "${SG_ID:-}" ] || [ "$SG_ID" = "None" ]; then
  say "Creating security group '$SG_NAME'..."
  SG_ID=$(aws ec2 create-security-group --region "$REGION" \
    --group-name "$SG_NAME" \
    --description "Vanity sniper - SSH only" \
    --query 'GroupId' --output text)
  aws ec2 authorize-security-group-ingress --region "$REGION" \
    --group-id "$SG_ID" --protocol tcp --port 22 --cidr "$SSH_CIDR" >/dev/null
  echo "  SG: $SG_ID (SSH from $SSH_CIDR)"
else
  say "Security group '$SG_NAME' already exists — reusing ($SG_ID)."
fi

# ---------- 4. Bootstrap script (runs on the instance) ----------
BOOTSTRAP=$(cat <<EOF
#!/bin/bash
set -euxo pipefail
exec > /var/log/sniper-bootstrap.log 2>&1

dnf update -y
dnf install -y docker git unzip
systemctl enable --now docker
usermod -aG docker ec2-user

mkdir -p /opt/sniper
cd /opt/sniper

# Get the code: prefer git clone, fall back to the uploaded zip
if [ ! -d /opt/sniper/app ]; then
  git clone --depth 1 -b ${BRANCH} ${REPO_URL} /opt/sniper/repo || true
fi

SRC=/opt/sniper/repo
if [ ! -f "\$SRC/main.js" ]; then
  ZIP=\$(ls "\$SRC"/*.zip 2>/dev/null | head -1 || true)
  if [ -n "\$ZIP" ]; then
    mkdir -p /opt/sniper/app
    unzip -o "\$ZIP" -d /opt/sniper/app
    SRC=/opt/sniper/app
  fi
fi

[ -f "\$SRC/main.js" ] || { echo "FATAL: main.js not found in repo or zip"; exit 1; }

cd "\$SRC"
docker build -t vanity-sniper .
echo "BUILD_OK"
EOF
)

# ---------- 5. Launch ----------
say "Launching EC2 instance..."
INSTANCE_ID=$(aws ec2 run-instances --region "$REGION" \
  --image-id "$AMI" \
  --instance-type "$INSTANCE_TYPE" \
  --key-name "$KEY_NAME" \
  --security-group-ids "$SG_ID" \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=vanity-sniper}]' \
  --user-data "$BOOTSTRAP" \
  --query 'Instances[0].InstanceId' --output text)
echo "  Instance: $INSTANCE_ID"

say "Waiting for instance to boot..."
aws ec2 wait instance-running --instance-ids "$INSTANCE_ID" --region "$REGION"
aws ec2 wait instance-status-ok --instance-ids "$INSTANCE_ID" --region "$REGION"

PUBLIC_IP=$(aws ec2 describe-instances --region "$REGION" --instance-ids "$INSTANCE_ID" \
  --query 'Reservations[0].Instances[0].PublicIpAddress' --output text)

cat <<EOF

==============================================================
  EC2 IS UP  (Docker image may still be building ~2-3 min)
==============================================================
  Instance ID : $INSTANCE_ID
  Public IP   : $PUBLIC_IP
  SSH         : ssh -i $KEY_NAME.pem ec2-user@$PUBLIC_IP
  Build log   : sudo tail -f /var/log/sniper-bootstrap.log

  NEXT: put your secrets in /opt/sniper/.env on the server
  ------------------------------------------------------------
  ssh -i $KEY_NAME.pem ec2-user@$PUBLIC_IP
  sudo tee /opt/sniper/.env >/dev/null <<'ENV'
SNIPER_TOKEN_MONITOR=your_monitor_token
SNIPER_TOKEN_SNIPER=your_sniper_token
SNIPER_PASSWORD=your_account_password
SNIPER_TARGET_GUILD_ID=your_guild_id
SNIPER_WEBHOOK_URL=
SNIPER_GRACE_DAYS=30
SNIPER_FAST_FETCH=false
ENV
  sudo chmod 600 /opt/sniper/.env

  # start it (auto-restarts on crash/reboot)
  sudo docker run -d --restart unless-stopped --name sniper \\
    --env-file /opt/sniper/.env vanity-sniper

  # watch logs
  sudo docker logs -f sniper
==============================================================
EOF
