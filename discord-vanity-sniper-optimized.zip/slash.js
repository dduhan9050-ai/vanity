// Slash command support for the Vanity Sniper.
// Requires a Discord BOT application (bot token + application ID).
// User tokens cannot provide slash commands — this module uses the bot identity
// only for interactions; the actual vanity claiming still uses the user tokens.
const WebSocket = require('ws');
const fs = require('fs');

const DISCORD_API = 'https://discord.com/api/v9';
const CONFIG_FILE_PATH = './config.json';
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

let CONFIG = null;
let STATE = null;
let ownerId = null;     // cached guild owner id
let lastLatency = null; // ms

function loadConfigFile() {
  try {
    if (fs.existsSync(CONFIG_FILE_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_FILE_PATH, 'utf8'));
    }
  } catch {}
  return {};
}

function saveConfigFile() {
  try {
    const data = {
      token_monitor: CONFIG.token_monitor || "",
      token_sniper: CONFIG.token_sniper || "",
      password: CONFIG.password || "",
      target_guild_id: CONFIG.target_guild_id || "",
      bot_token: CONFIG.bot_token || "",
      application_id: CONFIG.application_id || "",
      admin_user_id: CONFIG.admin_user_id || "",
    };
    fs.writeFileSync(CONFIG_FILE_PATH, JSON.stringify(data, null, 2), { mode: 0o600 });
  } catch (e) {
    console.error("[Slash] Could not save config.json:", e.message);
  }
}

async function registerCommands() {
  const commands = [
    {
      name: 'settoken',
      description: 'Set the monitor or sniper token',
      options: [
        {
          type: 3,
          name: 'type',
          description: 'Which token to set',
          required: true,
          choices: [
            { name: 'monitor', value: 'monitor' },
            { name: 'sniper', value: 'sniper' },
          ],
        },
        { type: 3, name: 'token', description: 'The token value', required: true },
      ],
    },
    { name: 'status', description: 'Show bot status' },
    { name: 'latency', description: 'Show gateway latency' },
  ];

  const res = await fetch(`${DISCORD_API}/applications/${CONFIG.application_id}/guild-commands`, {
    method: 'PUT',
    headers: {
      Authorization: `Bot ${CONFIG.bot_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(commands),
  });

  if (!res.ok) {
    throw new Error(`Command registration failed (${res.status})`);
  }
  console.log('[Slash] Registered commands: /settoken /status /latency');
}

async function getGuildOwner() {
  if (ownerId) return ownerId;
  try {
    const res = await fetch(`${DISCORD_API}/guilds/${CONFIG.target_guild_id}`, {
      headers: { Authorization: `Bot ${CONFIG.bot_token}` },
    });
    if (res.ok) {
      const g = await res.json();
      ownerId = g.owner_id;
    }
  } catch {}
  return ownerId;
}

async function isAuthorized(userId) {
  if (CONFIG.admin_user_id) return String(userId) === String(CONFIG.admin_user_id);
  const owner = await getGuildOwner();
  return owner ? String(userId) === String(owner) : true;
}

async function respond(interaction, content) {
  try {
    await fetch(`${DISCORD_API}/interactions/${interaction.id}/${interaction.token}/callback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 4, data: { content } }),
    });
  } catch {}
}

function buildStatus() {
  const lines = [];
  lines.push('📡 **Status**');
  lines.push(`• Monitor token: ${CONFIG.token_monitor ? '✅ set' : '❌ missing'}`);
  lines.push(`• Sniper token: ${CONFIG.token_sniper ? '✅ set' : '❌ missing'}`);
  lines.push(`• Target guild: ${CONFIG.target_guild_id || '❌ not set'}`);
  lines.push(`• Gateway: ${STATE && STATE.wsConnected ? '🟢 connected' : '🔴 disconnected'}`);
  lines.push(`• Fast fetch: ${CONFIG.use_fast_fetch ? 'ON (no JA3)' : 'off (CycleTLS)'}`);
  lines.push(`• Last claim: ${STATE.lastClaimTime ? new Date(STATE.lastClaimTime).toISOString() : '—'}`);
  return lines.join('\n');
}

async function handleInteraction(interaction) {
  const name = interaction.data && interaction.data.name;
  const userId = (interaction.member && interaction.member.user && interaction.member.user.id) ||
                 (interaction.user && interaction.user.id);

  let content = 'Unknown command.';

  if (name === 'settoken') {
    if (!(await isAuthorized(userId))) {
      content = '❌ You are not authorized to use this command.';
    } else {
      const opts = {};
      for (const o of interaction.data.options || []) opts[o.name] = o.value;
      const key = opts.type === 'monitor' ? 'token_monitor' : 'token_sniper';
      if (!opts.token) {
        content = '❌ Provide a token value.';
      } else {
        CONFIG[key] = opts.token.trim();
        saveConfigFile();
        content = `✅ ${opts.type} token saved. ` +
                  (opts.type === 'monitor' ? 'Restart needed for the gateway to pick it up.' : 'Will be used for the next claim.');
      }
    }
  } else if (name === 'status') {
    content = buildStatus();
  } else if (name === 'latency') {
    content = `⚡ **Gateway latency**: ${lastLatency !== null ? lastLatency + 'ms' : 'measuring…'}`;
  }

  await respond(interaction, content);
}

function connectInteractionGateway() {
  const ws = new WebSocket('wss://gateway.discord.gg/?encoding=json&v=9');
  let hbInterval = null;
  let lastHbSent = null;

  ws.on('open', () => {
    console.log('[Slash] Interaction gateway connected');
    ws.send(JSON.stringify({
      op: 2,
      d: {
        token: `Bot ${CONFIG.bot_token}`,
        intents: 0,
        properties: { os: 'linux', browser: 'node', device: '' },
      },
    }));
  });

  ws.on('message', async data => {
    let p;
    try { p = JSON.parse(data); } catch { return; }

    if (p.op === 10) {
      hbInterval = setInterval(() => {
        lastHbSent = Date.now();
        ws.send(JSON.stringify({ op: 1, d: null }));
      }, p.d.heartbeat_interval);
    }
    if (p.op === 11) {
      if (lastHbSent) lastLatency = Date.now() - lastHbSent;
    }
    if (p.op === 0 && p.t === 'INTERACTION_CREATE') {
      handleInteraction(p.d).catch(() => {});
    }
  });

  ws.on('close', () => {
    clearInterval(hbInterval);
    setTimeout(connectInteractionGateway, 5000);
  });

  ws.on('error', err => {
    console.error('[Slash] Gateway error:', err.message);
    ws.close();
  });
}

async function init({ config, state }) {
  CONFIG = config;
  STATE = state;

  if (!CONFIG.bot_token || !CONFIG.application_id) {
    console.log('[Slash] Disabled (no bot token / application ID). Slash commands need a Discord bot application.');
    return;
  }

  await registerCommands();
  connectInteractionGateway();
}

module.exports = { init };
