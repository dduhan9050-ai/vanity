# Project Notes

## discord-vanity-sniper (Node.js CLI bot)
- Run: `npm install && node main.js` (interactive setup prompts for tokens/password/guild ID).
- Requires real Discord tokens (monitor + sniper) and a target guild; cannot run in sandbox.
- Verify changes with `node --check main.js` (no web page to preview).
- Latency-critical path is `tryClaim()` in main.js — do NOT add network calls before the PATCH claim.
- Guild name is cached in `STATE.guildName` (refreshed hourly) to keep the claim path network-free.
- Gateway handler fires `tryClaim()` and `registerGrace()` concurrently (non-blocking); failure webhooks are fire-and-forget so the claim path never waits on them.
- `claimRequest()` helper routes claims through CycleTLS by default; set `CONFIG.use_fast_fetch=true` (prompt `y`) to use direct node-fetch (faster, no JA3 fingerprint, higher ban risk).
- Fast-fetch path uses a shared keep-alive `https.Agent` (`KEEP_ALIVE_AGENT`) and resolves node-fetch once, so repeat claims skip TLS re-handshake.
- AWS hosting: `Dockerfile`, `deploy-ec2.sh` (EC2 provisioning), and `README-DEPLOY-AWS.md` (guide). Bot is interactive on first run — use `docker run -it` for setup, then detached. No AWS creds in sandbox, so deploy runs from the user's machine.
