#!/usr/bin/env bash
# ============================================================
#  Deploy Discord Vanity Sniper to AWS EC2 (Amazon Linux 2023)
#  Run this ON YOUR LOCAL MACHINE with AWS CLI + credentials.
# ============================================================
set -euo pipefail

# ---- CONFIGURE THESE ----
AMI="ami-0f4e2f6d1f1f1f1f"        # Amazon Linux 2023 (change to your region's AMI)
INSTANCE_TYPE="t3.micro"           # cheap, enough for this bot
KEY_NAME="vanity-sniper-key"       # your EC2 key pair name
SECURITY_GROUP="vanity-sniper-sg"
REGION="${AWS_REGION:-us-east-1}"
# ---------------------------

echo "==> Checking AWS CLI..."
command -v aws >/dev/null || { echo "aws CLI not installed"; exit 1; }
aws sts get-caller-identity >/dev/null || { echo "No AWS credentials — run 'aws configure' first"; exit 1; }

echo "==> Creating security group (SSH only)..."
SG_ID=$(aws ec2 create-security-group \
  --group-name "$SECURITY_GROUP" \
  --description "Vanity sniper: SSH only" \
  --region "$REGION" \
  --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress \
  --group-id "$SG_ID" \
  --protocol tcp --port 22 --cidr 0.0.0.0/0 \
  --region "$REGION" >/dev/null

echo "==> Launching EC2 instance..."
INSTANCE_ID=$(aws ec2 run-instances \
  --image-id "$AMI" \
  --instance-type "$INSTANCE_TYPE" \
  --key-name "$KEY_NAME" \
  --security-group-ids "$SG_ID" \
  --region "$REGION" \
  --user-data "$(cat <<'EOF'
#!/usr/bin/env bash
set -e
yum update -y
yum install -y docker git
systemctl enable --now docker
usermod -aG docker ec2-user
cd /opt
git clone https://github.com/AeroX/discord-vanity-sniper.git sniper 2>/dev/null || true
cd /opt/sniper
docker build -t vanity-sniper .
echo "BUILD_DONE"
EOF
)" \
  --query 'Instances[0].InstanceId' --output text)

echo "==> Instance launching: $INSTANCE_ID"
echo "==> Waiting for running state..."
aws ec2 wait instance-running --instance-ids "$INSTANCE_ID" --region "$REGION"

PUBLIC_IP=$(aws ec2 describe-instances \
  --instance-ids "$INSTANCE_ID" \
  --region "$REGION" \
  --query 'Reservations[0].Instances[0].PublicIpAddress' --output text)

echo ""
echo "=============================================================="
echo "  DEPLOY COMPLETE"
echo "=============================================================="
echo "  Instance ID : $INSTANCE_ID"
echo "  Public IP   : $PUBLIC_IP"
echo "  SSH         : ssh -i $KEY_NAME.pem ec2-user@$PUBLIC_IP"
echo ""
echo "  Next steps (on the server):"
echo "    1. ssh -i $KEY_NAME.pem ec2-user@$PUBLIC_IP"
echo "    2. cd /opt/sniper"
echo "    3. docker run -it --rm vanity-sniper   # first interactive setup"
echo "    4. docker run -d --restart unless-stopped --name sniper vanity-sniper"
echo "=============================================================="
