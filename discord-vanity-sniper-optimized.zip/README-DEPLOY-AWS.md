# 🚀 AWS EC2 Deployment Guide — Discord Vanity Sniper

This guide hosts the optimized bot on **AWS EC2** (a 24/7 Linux server).

> **Note:** This sandbox has no AWS credentials, so I can't deploy *into* your
> account for you. Everything below is ready to run from your own machine
> (with AWS CLI + credentials). The deployment files are already in this repo.

---

## Option A — One-click script (recommended)

### 1. Prerequisites (on your local machine)
- AWS account + **IAM user with EC2 full access**
- AWS CLI installed & configured:
  ```bash
  aws configure          # enter access key / secret / region
  ```
- An EC2 **key pair** (or create one):
  ```bash
  aws ec2 create-key-pair --key-name vanity-sniper-key --query 'KeyMaterial' --output text > vanity-sniper-key.pem
  chmod 400 vanity-sniper-key.pem
  ```

### 2. Edit the script
Open `deploy-ec2.sh` and set your **AMI ID** for your region
(Amazon Linux 2023, e.g. `us-east-1` → `ami-0f4e2f6d1f1f1f1f`),
your key name, and region.

### 3. Run it
```bash
chmod +x deploy-ec2.sh
./deploy-ec2.sh
```
It creates a security group (SSH only), launches the instance, installs Docker,
and builds the image. It prints the **Public IP** at the end.

### 4. SSH in & run the bot
```bash
ssh -i vanity-sniper-key.pem ec2-user@<PUBLIC_IP>
cd /opt/sniper
# First run = interactive setup (tokens / password / guild ID):
docker run -it --rm vanity-sniper
# Then run it detached as a persistent service:
docker run -d --restart unless-stopped --name sniper vanity-sniper
```

---

## Option B — Manual (no script)

```bash
# 1. Launch EC2 (Amazon Linux 2023, t3.micro, SSH sg)
# 2. SSH in:
ssh -i your-key.pem ec2-user@<IP>

# 3. Install Docker:
sudo yum update -y
sudo yum install -y docker git
sudo systemctl enable --now docker
sudo usermod -aG docker ec2-user

# 4. Copy your project files up (from your machine):
scp -i your-key.pem main.js package.json Dockerfile ec2-user@<IP>:/home/ec2-user/

# 5. Build & run:
cd /home/ec2-user
docker build -t vanity-sniper .
docker run -it --rm vanity-sniper          # first setup
docker run -d --restart unless-stopped --name sniper vanity-sniper
```

---

## Keeping it running
- `docker run -d --restart unless-stopped` auto-restarts on reboot/crash. ✅
- Logs: `docker logs -f sniper`
- Stop: `docker stop sniper`
- Update code: rebuild image (`docker build -t vanity-sniper .`) then
  `docker rm -f sniper && docker run -d --restart unless-stopped --name sniper vanity-sniper`

## Security notes
- The security group opens **SSH only** — the bot only makes outbound calls
  to Discord, so no inbound web ports are needed.
- Keep your key pair `.pem` file private.
- Your Discord tokens live only inside the instance (not in the repo).

## Cost
- `t3.micro` ≈ **~$0.0116/hr** (on-demand, us-east-1) ≈ **~$8.40/month**.
- Free tier eligible for 12 months if you're a new AWS account.
